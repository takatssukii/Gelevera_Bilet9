﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Gelevera_Bilet9
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBoxLogin_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxLogin.Text.Length < 4 || textBoxLogin.Text.Length > 35)
            {
                textBoxLogin.Background = Brushes.Red;
                string text = "Поле <Логин> должно содержать 4-35 символов";
                textBlockLogin.Text = text;

            }
            else
            {
                textBoxLogin.Background = Brushes.Green;
                string text1 = "Все верно";
                textBlockLogin.Text = text1;
            }
        }

        private void TextBoxPass_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxPass.Text.Length < 10 || textBoxPass.Text.Length > 100)
            {
                textBoxPass.Background = Brushes.Red;
                string text3 = "Поле <Пароль> должно содержать 10-100 символов";
                textBlockPass.Text = text3;

            }
            else
            {
                textBoxPass.Background = Brushes.Green;
                string text4 = "Все верно";
                textBlockPass.Text = text4;
            }
        }

        private void mailbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string emailPattern = @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
            bool isItEmail = System.Text.RegularExpressions.Regex.IsMatch(mailbox.Text, emailPattern);
            if (isItEmail == true)
            {
                mailbox.Background = Brushes.Green;
                string text = "Верный email";
                mailblock.Text = text;
            }
            else
            {
                mailbox.Background = Brushes.Red;
                string text = "Неверный email";
                mailblock.Text = text;
            }
        }


    }
}
